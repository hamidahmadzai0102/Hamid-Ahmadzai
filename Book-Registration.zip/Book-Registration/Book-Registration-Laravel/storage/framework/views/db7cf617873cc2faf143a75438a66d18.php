<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'My Reading List'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
    <div class="container py-2">
        <a class="navbar-brand fw-bold" href="<?php echo e(url('/')); ?>">▤ &nbsp; My Reading List</a>
        <?php if(auth()->guard()->check()): ?>
            <div class="d-flex align-items-center gap-3">
                <span class="text-light small"><?php echo e(auth()->user()->name); ?></span>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-outline-light btn-sm" type="submit">Log out</button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</nav>
<main class="container py-5">
    <?php if(session('success')): ?>
        <div class="alert alert-success" role="status"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
</main>
<footer class="container text-muted small pb-4">BOOK REGISTRATION LAB · Laravel &amp; MySQL</footer>
</body>
</html>
<?php /**PATH C:\Book-Registration\Book-Registration-Laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>