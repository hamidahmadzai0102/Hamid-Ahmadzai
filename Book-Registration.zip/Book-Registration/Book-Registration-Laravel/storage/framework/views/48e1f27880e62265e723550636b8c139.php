<?php $__env->startSection('content'); ?>
<header class="d-flex flex-wrap justify-content-between align-items-end gap-3 mb-4">
    <div><p class="eyebrow">MY PERSONAL LIBRARY</p><h1 class="fw-bold mb-2">One book at a time.</h1>
    <p class="text-muted mb-0">Keep the books you want to remember, all in one place.</p></div>
    <span class="badge rounded-pill text-bg-light border px-3 py-2"><?php echo e($books->count()); ?> <?php echo e($books->count() === 1 ? 'book' : 'books'); ?> registered</span>
</header>
<div class="row g-4">
    <section class="col-lg-4" aria-labelledby="add-heading">
        <div class="card shadow-sm"><div class="card-body p-4">
            <h2 class="h4 mb-1" id="add-heading">Register a book</h2>
            <p class="text-muted small mb-4">Add the details to grow your collection.</p>
            <form method="POST" action="<?php echo e(route('books.store')); ?>">
                
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label" for="title">Title</label>
                    <input class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="title" name="title" value="<?php echo e(old('title')); ?>" maxlength="150" placeholder="e.g. Learning PHP" required>
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="author">Author</label>
                    <input class="form-control <?php $__errorArgs = ['author'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="author" name="author" value="<?php echo e(old('author')); ?>" maxlength="100" placeholder="e.g. Sara Ahmad" required>
                    <?php $__errorArgs = ['author'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-4">
                    <label class="form-label" for="pages">Pages</label>
                    <input class="form-control <?php $__errorArgs = ['pages'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pages" name="pages" type="number" value="<?php echo e(old('pages')); ?>" min="1" max="10000" step="1" placeholder="e.g. 120" required>
                    <?php $__errorArgs = ['pages'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="form-text">Between 1 and 10,000 pages.</div>
                </div>
                <button class="btn btn-primary w-100" type="submit">+ Register book</button>
            </form>
        </div></div>
    </section>
    <section class="col-lg-8" aria-labelledby="books-heading">
        <div class="card shadow-sm overflow-hidden">
            <div class="card-body p-4 border-bottom"><h2 class="h4 mb-1" id="books-heading">My Books</h2>
            <p class="text-muted small mb-0">Your latest additions appear first.</p></div>
            <?php if($books->isEmpty()): ?>
                <div class="p-5 text-center"><div class="empty-icon mb-3">▤</div>
                <h3 class="h5">Your shelf is waiting.</h3><p class="text-muted mb-0">No books registered yet. Add your first book using the form.</p></div>
            <?php else: ?>
                <div class="table-responsive"><table class="table align-middle mb-0">
                    <thead class="table-light"><tr><th scope="col">No.</th><th scope="col">Title</th><th scope="col">Author</th><th scope="col" class="text-end">Pages</th></tr></thead>
                    <tbody><?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr><td class="text-muted"><?php echo e($loop->iteration); ?></td><td class="fw-semibold book-title"><?php echo e($book->title); ?></td><td class="book-author"><?php echo e($book->author); ?></td><td class="text-end"><?php echo e(number_format($book->pages)); ?></td></tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody>
                </table></div>
            <?php endif; ?>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Book-Registration\Book-Registration-Laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>