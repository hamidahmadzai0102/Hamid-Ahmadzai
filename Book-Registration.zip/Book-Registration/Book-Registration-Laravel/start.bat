@echo off
setlocal
cd /d "%~dp0"
if exist "C:\xampp\php\php.exe" set "PATH=C:\xampp\php;%PATH%"
if not exist vendor\autoload.php goto setup_required
if not exist .env goto setup_required
php artisan serve --host=127.0.0.1 --port=8000
pause
exit /b
:setup_required
echo Run setup.bat first.
pause
exit /b 1
