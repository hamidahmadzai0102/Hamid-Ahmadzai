<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Book extends Model
{
    // These fields can be saved using Book::create().
    protected $fillable = ['user_id', 'title', 'author', 'pages'];

    protected function casts(): array
    {
        return ['pages' => 'integer'];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
