@extends('layouts.app')
@section('title', 'Create account · My Reading List')
@section('content')
<div class="auth-wrap mx-auto">
<p class="eyebrow">START YOUR COLLECTION</p><h1 class="fw-bold">A shelf of your own.</h1>
<p class="text-muted mb-4">Create an account. Your reading list is private to you.</p>
<div class="card shadow-sm"><div class="card-body p-4">
<form method="POST" action="{{ route('register') }}">
@csrf
<div class="mb-3"><label class="form-label" for="name">Full name</label>
<input class="form-control @error('name') is-invalid @enderror" id="name" name="name" type="text" value="{{ old('name') }}" autocomplete="name" required maxlength="100">
@error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
</div><div class="mb-3"><label class="form-label" for="email">Email address</label>
<input class="form-control @error('email') is-invalid @enderror" id="email" name="email" type="email" value="{{ old('email') }}" autocomplete="email" required maxlength="255">
@error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
</div><div class="mb-3"><label class="form-label" for="password">Password</label>
<input class="form-control @error('password') is-invalid @enderror" id="password" name="password" type="password" autocomplete="new-password" required minlength="8">
@error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
</div><div class="mb-3"><label class="form-label" for="password_confirmation">Confirm password</label>
<input class="form-control @error('password_confirmation') is-invalid @enderror" id="password_confirmation" name="password_confirmation" type="password" autocomplete="new-password" required minlength="8">
@error('password_confirmation')<div class="invalid-feedback">{{ $message }}</div>@enderror
</div>
<p class="small text-muted">Use a password with at least 8 characters.</p>
<button class="btn btn-primary w-100" type="submit">Create account</button>
</form>
<p class="small mt-4 mb-0">Already registered? <a href="{{ route('login') }}">Log in</a></p>
</div></div></div>
@endsection
